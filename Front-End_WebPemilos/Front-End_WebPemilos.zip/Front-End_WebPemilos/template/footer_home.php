 <!-- Footer -->
 <div class="footer">

  <!-- <div style="width: 100px;"></div>  -->
  <div class="center-text">Panitia OSIS 2025</div>
  <div class="buttons">
    

  </div>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="../css/styleHome.css">
</head>

<header>
    <div class="logo">
      <img src="Screenshot (16).png" alt="Logo">
      <h1>PEMILOS 2025</h1>
    </div>
    <div class="btn">
        <button onclick="window.location.href='index.php'">Home</button>
        <button class="btn" onclick="window.location.href='statistik.php'">Statistik</button>
       <button class="btn" onclick="window.location.href='login.php'">Login</button>
    </div>
  </header>